import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import './App.css';

import UAppointments from './components/UAppointments';
import HomePage from './components/HomePage';

function App() {
  return (
    <Router> {/* Wrap your components that use routing with Router */}
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/appointments" element={<UAppointments />} />
      </Routes>
    </Router>
  );
}

export default App;
