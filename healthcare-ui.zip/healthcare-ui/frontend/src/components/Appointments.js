import React from 'react';
import Carousel from 'react-bootstrap/Carousel';
import './Appointments.css';
import Button from 'react-bootstrap/Button';
import { navigate } from 'react-router-dom';
import { Link } from 'react-router-dom';


function Appointments() {

  const image1 = require('../assets/1.jpg');
  const image2 = require('../assets/2.jpeg');
  const image3 = require('../assets/3.jpeg');



  

  return (

    <>
      <div>
        <Carousel>
          <Carousel.Item>
            <img className="image1" src={image1} alt="First slide" />
          </Carousel.Item>
          <Carousel.Item>
            <img className="image2" src={image2} alt="Second slide" />
          </Carousel.Item>
          <Carousel.Item>
            <img className="image3" src={image3} alt="Third slide" />
          </Carousel.Item>
        </Carousel>

      </div>

      <Link to="/appointments" style={{ textDecoration: 'none' }}> 
        <div className='app_button'>
          <Button as="input" type="button" value="Book Your Appointment" />{' '}
        </div>
      </Link>


    </>


  );


}

export default Appointments;
