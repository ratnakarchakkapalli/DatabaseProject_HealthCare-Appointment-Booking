import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
    return (
        <div>
            <h1 className="home-title">Welcome to the Healthcare Appointment System</h1>
            <div className="image-container">
                <img src="/healthcare.png" alt="Healthcare" />
            </div>
            <div className="button-container">
                <Link to="/appointments" className="appointment-button">Get Appointment</Link>
            </div>
        </div>
    );
}

export default Home;
