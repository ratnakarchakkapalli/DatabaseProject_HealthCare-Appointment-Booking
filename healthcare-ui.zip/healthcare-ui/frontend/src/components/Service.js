import React from 'react';
import Card from 'react-bootstrap/Card';
import './Service.css';  

import generalConsultationImage from '../assets/gc.jpeg';
import pediatricCareImage from '../assets/ped.jpeg';
import cardiologyImage from '../assets/card.jpeg';
import dermatologyImage from '../assets/dermat.jpeg';
import moreServicesImage from '../assets/service.jpg';


const servicesData = [
    {
      id: 1,
      title: "General Consultation",
      imageUrl: generalConsultationImage,
      description: "Comprehensive medical examinations to ensure your well-being."
    },
    {
      id: 2,
      title: "Pediatric Care",
      imageUrl: pediatricCareImage,
      description: "Access to top medical specialists to address specific health concerns."
    },
    {
      id: 3,
      title: "Cardiology",
      imageUrl: cardiologyImage,
      description: "State-of-the-art diagnostic tools to accurately diagnose health issues."
    },
    {
      id: 4,
      title: "Dermatology",
      imageUrl: dermatologyImage,
      description: "Remote consultations and health services from the comfort of your home."
    },
    {
      id: 5,
      title: "More Services",
      imageUrl: moreServicesImage,
      description: "Programs and tips to promote healthy lifestyles and prevent disease."
    }
   
      
  ];

// Designing the card
function Service() {
  return (
    <>
      <h3 className='ser-header'>Our Services</h3>
      <div className="services-cards-container">
        {servicesData.map(service => (
          <Card key={service.id} className="service-card">
            <Card.Img variant="top" src={service.imageUrl} alt={service.title} />
            <Card.Body>
              <Card.Title>{service.title}</Card.Title>
              <Card.Text>{service.description}</Card.Text>
            </Card.Body>
          </Card>
        ))}
      </div>
    </>
  );
}

export default Service;