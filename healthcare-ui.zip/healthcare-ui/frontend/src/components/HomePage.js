import React from 'react';
import Appointments from './Appointments';
import Service from './Service';
import Foot from './Foot';
import Navbar from './Navbar';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';



const HomePage = () => {
    return (
        <div>
            <Navbar />
            <Appointments />
            <Service />
            <Foot />
        </div>
    )
}

export default HomePage
