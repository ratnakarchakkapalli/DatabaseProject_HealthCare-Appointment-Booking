import React, { useState, useEffect } from "react";
import axios from "axios";
import Foot from "./Foot";


function UAppointments() {
  const [appointments, setAppointments] = useState([]);
  const [error, setError] = useState('');

  // here we connect to backend and fetch details from the backend
  useEffect(() => {
    axios.get('http://localhost:3001/appointments')
      .then(response => {
        setAppointments(response.data);
      })
      .catch(error => {
        console.error('Failed to fetch appointments: ', error);
        setError('Failed to fetch appointments');
      })
  }, []);

  return (
    <div>
      <h1>Appointment Details</h1>
      {appointments.length > 0 ? (
        <table>
          <thead>
            <tr>
              <th>Appointment ID</th>
              <th>Date and Time</th>
              <th>Status</th>
              <th>Details</th>
            </tr>
          </thead>
          <tbody>
            {appointments.map((appointment, index) => (
              <tr key={index}>
                <td>{appointment.Appointment_ID}</td>
                <td>{appointment.Date_Time}</td>
                <td>{appointment.Status}</td>
                <td>{appointment.Details}</td>
              </tr>
            ))}
          </tbody>
        </table>
      ) : (
        <p>Sorry, there are no records of appointments to display.</p>
      )}
      {error && <p>{error}</p>}
    </div>
  );
}

export default UAppointments;
