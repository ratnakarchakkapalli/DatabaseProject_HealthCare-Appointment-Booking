import React from 'react';
import './Foot.css'; 

const Foot = () => {
  return (
    <footer className="footer">
      <div className="about">
        <h4>About Us</h4>
        <div className="team-members">
          <span className="team-member">Kartik</span>
          <span className="team-member">Yu Du</span>
          <span className="team-member">Santosh</span>
          <span className="team-member">Shreya</span>
          <span className="team-member">Aman</span>
        </div>
      </div>
      <div className="footer-bottom">
        <p>© Group 14 --- DAMG 6210 Database Management and Database Design</p>
      </div>
    </footer>
  );
};

export default Foot;
