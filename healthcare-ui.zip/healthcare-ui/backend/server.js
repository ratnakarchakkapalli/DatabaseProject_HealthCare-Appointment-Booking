// Here we are setting up a simple Node.js server using Express.js, we are using MYSQL for database integration
// our server.js file basically returns basically reads or writes from database based on the type of HTTP request and then returns data to the client



const express = require('express');  // Imports the Express framework that is used to creating the server and handling API requests 
const cors = require('cors');   // Imports the CORS package ( Cross Origin Resource Sharing) middleware that allow or restricts requested resources on a server based on where request is generated
const mysql = require('mysql');  // Imports MYSQL library to enable interaction with MYSQL databases
const { populate } = require('dotenv');

const pool = mysql.createPool({
  connectionLimit: 10,  //sets maximum no of connections that can be created in the pool
  host: 'localhost', 
  user: 'root', 
  password: 'root',
  database: 'ohabp'
});

const app = express(); //initializes an instance of express.js app      
app.use(cors());  //applies cors middleware to allow all domains to make requests to the API
app.use(express.json()); //adds middleware to parse JSON-formatted request bodies.





// Endpoint to fetch appointments
// this is the part where API is defined

app.get('/appointments', (req, res) => {
  pool.query('SELECT * FROM Appointment', (error, results) => {
    if (error) {
      return res.status(500).json({ error });
    }
    res.json(results);
  });
});
  

app.post('/createappointment',(req,res)=>{
     const {appointmentID,Date_Time,Status,Details}=req.body;


    pool.query('INSERT INTO Appointment (appointmentDate, patientName, appointmentType) VALUES (?, ?, ?)',[appointmentID,Date_Time,Status,Details],(error,results)=>{

     if(error){
      return res.status(500).json({error});
     }
      res.json({id: results.insertId});

    }
  );

});
// callback function with req and response objects defined used by a route handler for GET requests
// if error exists in query sends a 500 internal server error response with error object
// if no error sends result of query back to client in JSON format


const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
//Determines the PORT on which server will listen. Uses the environment variable 'PORT' of available or it defaults to 3001


