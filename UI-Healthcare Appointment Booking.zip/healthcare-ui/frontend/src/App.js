import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import './App.css'; 
import { useState, useEffect } from 'react';
import axios from 'axios';



function Navbar() {
  return (
    <nav>
      <h1>Healthcare Appointment Booking</h1>
      <div>
        <Link to="/">Home</Link>
      </div>
    </nav>
  );
}

function Home() {
  return (
    <div>
      <h1 className="home-title">Welcome to the Healthcare Appointment System</h1>
      <div className="image-container">
        <img src="/healthcare.png" alt="Healthcare" />
      </div>
      <div className="button-container">
        <Link to="/appointments" className="appointment-button">Get Appointment</Link>
      </div>
    </div>
  );
}

function Appointments() {
  return (
    <h1>Appointment Details</h1>
  );
}

function Footer() {
  const [appointments, setAppointments] = useState([]);

  useEffect(() => {
      axios.get('http://localhost:3001/appointments') 
          .then(response => {
              setAppointments(response.data);
          })
          .catch(error => {
              console.error('Failed to fetch appointments:', error);
          });
  }, []);

  return (
      <div>
          <h1>Appointment Details</h1>
          {appointments.length > 0 ? (
              appointments.map((appointment, index) => (
                  <div key={index}>
                      <p>Appointment ID: {appointment.Appointment_ID}</p>
                      <p>Date and Time: {appointment.Date_Time}</p>
                      <p>Status: {appointment.Status}</p>
                      <p>Details: {appointment.Details}</p>
                  </div>
              ))
          ) : (
              <p>No appointments found.</p>
          )}
      </div>
  );


}

function App() {
  return (
    <Router>
      <div className="App">
        <Navbar />
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/appointments" element={<Appointments />} />
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
